package com.project.ThreadsPlusSockets;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThreadsPlusSocketsApplicationTests {

	@Test
	void contextLoads() {
	}

}
