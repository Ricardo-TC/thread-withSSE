package com.project.ThreadsPlusSockets;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThreadsPlusSocketsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ThreadsPlusSocketsApplication.class, args);
	}

}
